# Práctica con pipelines
En esta carpeta vamos a tener el contenido de la práctica de las clases en vivo. Utilizado a partir de la clase 14.
