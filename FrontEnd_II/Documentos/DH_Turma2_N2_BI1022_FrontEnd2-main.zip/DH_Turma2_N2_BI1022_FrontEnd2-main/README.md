# Turma2 N2-BI1022 FrontEnd2 - Digital House Brasil

Seja bem-vind@ Dev!!

Este é o repositório público da Turma 2 do 3° bimestre(BI1022) do Certified Tech Developer(CTD) na Digital House Brasil.

## Aqui você encontrara:
- Códigos desenvolvidos em aula durante o bimestre;
- Códigos base para atividades e checkpoints da disciplina;
- Materiais complementares diversos para as aulas;

### Tem alguma dúvida ou sugestão?
Entre em contato: mmartins@digitalhouse.com