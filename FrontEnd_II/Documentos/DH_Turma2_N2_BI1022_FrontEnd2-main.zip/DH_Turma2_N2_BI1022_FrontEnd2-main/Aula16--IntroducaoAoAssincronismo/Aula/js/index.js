/* Aula 16 - Introdução ao assincronimso e Promises */
/* Nesta aula estamos apenas "Simulando" requisições assincronas ao utilizar as promises */
