//Importa o script

/* Importando e dando um apelido para as funções */
import {estudandoArrays as estudando , nomeUsuario as name} from './aula3_script.js';

/* Chamando as funções */
estudando();
name();