 function somar(valor1Recebido, valor2Recebido) {
  let valor1 = parseFloat(valor1Recebido);
  let valor2 = parseFloat(valor2Recebido);
  return valor1 + valor2;
}

export default somar;