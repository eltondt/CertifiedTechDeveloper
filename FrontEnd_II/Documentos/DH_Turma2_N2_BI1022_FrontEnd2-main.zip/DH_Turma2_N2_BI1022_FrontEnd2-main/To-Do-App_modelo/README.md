Este é um modelo de como pode ser informada a contribuição de cada membro do grupo no checkpoint 2 da disciplina de Front end 2.

## Autores (Contribuições)

- [Marcos V. Martins](https://www.github.com/xk08)
    - Principais atividades realizadas:
        - Layout do Login;
        - Tela de login;
        - Comunicação inicial com a API;
        - Endpoint: /login
        
- [Aluna A](https://www.github.com/xk08)
    - Principais atividades realizadas:
        - Layout do Cadastro;
        - Tela de Cadastro;
        - Endpoint: /criarCadastro;

- [Aluno B](https://www.github.com/xk08)
    - Principais atividades realizadas:
        - Escolha do layout do projeto;
        - Revisões de código;
        - Alertas e pop-up;
