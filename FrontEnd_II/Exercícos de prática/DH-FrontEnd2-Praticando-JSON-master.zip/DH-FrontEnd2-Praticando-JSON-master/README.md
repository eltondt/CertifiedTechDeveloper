# Praticando JSON

Utilize este repositório para praticar o acesso aos dados em formato JSON.

A atividade prática se encontra em ```./js/index.js```.
