function normalizaStringUsandoTrim(textoRecebido) {
    return textoRecebido.trim();
}

function baseURL(){
    return "http://todo-api.ctd.academy:3000/v1"
}