# checkpoint-II_front-end-II
Checkpoint final de front end II
Gustavo Brito: Parte de validações de Login e cadastro, conexões com a API, aplicações das animações de loading

Elton Tomé: Parte de validação de cadastro

Lucas Santos: Parte de criação de tarefas, atualização, exclusão, atualização e também responsável por fazer a parte de pegar as informações do usuario para aparecer o nome.